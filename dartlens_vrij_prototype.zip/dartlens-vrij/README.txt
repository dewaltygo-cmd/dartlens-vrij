DartLens Vrij — prototype

Wat werkt:
- iPhone-geschikte webinterface met camera-preview (achtercamera)
- kalibratie door bull en buitenrand aan te tikken
- scoreberekening op basis van een tikpositie
- 301/501, spelerskeuze, lijst met worpen, undo en nieuw spel
- geen account, abonnement of server nodig voor scoregegevens

Belangrijke beperking:
Dit prototype herkent de dartpunt nog NIET automatisch uit camerabeelden. De gebruiker tikt zelf op de punt in het camerabeeld. De scoreberekening is experimenteel en vereist goede kalibratie. De dubbele/triple-ringverhoudingen zijn benaderingen.

Gebruik op iPhone:
1. De camera werkt alleen in een veilige context zoals HTTPS (of localhost); een lokaal geopend HTML-bestand kan geen camera-toegang krijgen in iOS.
2. Voor een snelle test kun je de bestanden hosten op een gratis HTTPS static host (bijv. GitHub Pages) of openen via een lokale ontwikkelserver.
3. Tik op Start camera en geef toestemming.
4. Tik op 'Tik daarna op bull', tik op het midden van de bull.
5. Tik op 'Tik daarna op buitenrand', tik op de buitenrand van de dubbele ring.
6. Tik op de plek van de dartpunt om de score te berekenen.

Volgende ontwikkelstap voor echte automatische detectie:
- beeldregistratie/kalibratie en correctie van perspectief
- dartpunt-detectie met computer vision (bijv. OpenCV/WebAssembly of Core ML)
- detectie van nieuwe darts door vergelijking van frames
- testen met verschillende belichting, schaduwen, darts en bordtypes
